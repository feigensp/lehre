import static org.junit.Assert.*;

import org.junit.Test;


public class MyEngineTest {

	@Test
	public void testUpdate() {
		Engine eng = new Engine();
		assertTrue("Test ob Engine Ger�usche macht beim fahren", "Brummmm!".equals(eng.update("f�hrt")));
		assertTrue("Test ob Engine Ger�usche macht beim fahren", "zzz".equals(eng.update("parkt")));
	}

}
