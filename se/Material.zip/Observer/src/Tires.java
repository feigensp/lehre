
public class Tires implements IObserver{

	@Override
	public String update(String message) {
		String output = "";
		switch (message) {
		case "f�hrt":
			output = "quiiiiietsch";
			break;
		case "austrudeln":
			output = "brrrzsp";
			break;
		default:
			output = "zzz";
			break;
		}
		return output;
	}

}
