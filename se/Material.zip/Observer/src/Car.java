import java.util.*; 

public class Car implements ISubject{

	ArrayList<IObserver> observers = new ArrayList<IObserver>();
	String message = "parkt";
	
	public static void main(String[] args) {
		Car car = new Car();
		Tires t = new Tires();
		car.registerObserver(t);
		
		Engine e = new Engine();
		car.registerObserver(e);
		
		
		car.fahreLos();
		car.halteAn();

	}
	
	public void fahreLos() {
		this.message = "f�hrt";
		notifyObservers();
	}
	
	public void halteAn() {
		macheBespeil();
		this.message = "parkt";
		notifyObservers();
	}

	private void macheBespeil() {
		this.message = "austrudeln";
		notifyObservers();
	}
	
	public void registerObserver(IObserver observer) {
		this.observers.add(observer);
		
	}
	public void removeObserver(IObserver observer) {
		this.observers.remove(observer);
		
	}
	public void notifyObservers() {
		for(IObserver obs: observers) {
			System.out.println(obs.update(message));
		}
		
	}

}
