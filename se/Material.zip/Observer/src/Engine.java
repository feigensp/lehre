
public class Engine implements IObserver{

	public String update(String message) {
		String output = "";
		switch (message) {
		case "f�hrt":
			output = "Brummmm!";
			break;
		case "austrudeln":
			output = "tucker tucker tucker";
			break;
		default:
			//output = "zzz";
			break;
		}
		return output;
	}

}
