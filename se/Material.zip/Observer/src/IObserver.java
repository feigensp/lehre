
public interface IObserver {
	public String update(String message); 
}
