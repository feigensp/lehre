
public class LockedStack extends StackDecorator {
	
	boolean isLocked = false;
	
	public void lock()
	{
		isLocked = true;
	}
	
	public void unlock()
	{
		isLocked = false;
	}
	
	public LockedStack(IStack delegate)
	{
		super(delegate);
	}
	
	public Object pop()
	{
		if(isLocked)
		{
			System.out.println("Stack is locked.");
			return null;
		}
		else
			return super.pop();
	}
	
	public void push(Object o)
	{
		if(isLocked)
		{
			System.out.println("Stack is locked.");
		}
		else
			super.push(o);
	}
}
