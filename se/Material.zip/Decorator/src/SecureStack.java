
public class SecureStack extends StackDecorator {
	
	String keyphrase = "geheim!";
	
	public Object encrypt(Object o)
	{
		String encrypted = o.toString();
		encrypted = keyphrase.substring(0,3) + encrypted + keyphrase.substring(3,keyphrase.length()-3);
		return encrypted;
	}
	
	public Object decrypt(Object o)
	{
		if(o == null)
			return null;
		String decrypted = o.toString();
		decrypted = decrypted.substring(3);
		decrypted = decrypted.substring(0, decrypted.length() - keyphrase.length() - 3);
		return decrypted;
	}
	
	public SecureStack(IStack delegate)
	{
		super(delegate);
	}
	
	public Object pop()
	{
		return decrypt(super.pop());
	}
	
	public void push(Object o)
	{
		super.push(encrypt(o));
	}
}
