
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("=================================");
		System.out.println("Nur Basisimplementierung");
		System.out.println("=================================");
		IStack s = new Stack();
		s.push("Hello");
		s.push("World");
		
		System.out.println(s.pop());
		System.out.println(s.pop());
		
		System.out.println("=================================");
		System.out.println("Mit Locking");
		System.out.println("=================================");
		
		LockedStack ls = new LockedStack(s);
		ls.push("Hello");
		ls.push("World");
		ls.lock();
		System.out.println(ls.pop());
		ls.push("World");
		ls.unlock();
		
		System.out.println(ls.pop());
		System.out.println(ls.pop());
		
		System.out.println("=================================");
		System.out.println("Mit Verschl�sselung");
		System.out.println("=================================");
		
		SecureStack sec = new SecureStack(ls);
		sec.push("Hello");
		sec.push("World");
		ls.lock();
		System.out.println(sec.pop());
		sec.push("World");
		ls.unlock();
		
		System.out.println(sec.pop());
		System.out.println(sec.pop());
	}

}
