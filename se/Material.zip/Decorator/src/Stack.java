import java.util.*;

public class Stack implements IStack {

	ArrayList<Object> content = new ArrayList<Object>();
	@Override
	public void push(Object o) {
		content.add(0, o);		
	}

	@Override
	public Object pop() {
		if(content.size() > 0)
			return content.remove(0);
		else
			return null;
	}

	@Override
	public int size() {
		return content.size();
	}

}
