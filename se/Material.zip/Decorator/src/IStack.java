
public interface IStack {
	public void push(Object o);
	public Object pop();
	public int size();
}
