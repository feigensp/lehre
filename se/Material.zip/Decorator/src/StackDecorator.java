
public abstract class StackDecorator implements IStack{

	IStack delegate;
	public StackDecorator(IStack delegate) {
		this.delegate = delegate;
	}
	
	@Override
	public void push(Object o) {
		delegate.push(o);
	}

	@Override
	public Object pop() {
		return delegate.pop();
	}

	@Override
	public int size() {
		return delegate.size();
	}

}
