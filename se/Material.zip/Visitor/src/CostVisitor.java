
public class CostVisitor implements ICarElementVisitor{
	double overallCost = 0;
	public void visit(Wheel wheel) {
		System.out.println(wheel.cost);
		this.overallCost += wheel.cost;
	}

	public void visit(Engine engine) {
		System.out.println(engine.cost);
		this.overallCost += engine.cost;
	}

	public void visit(Body body) {
		System.out.println(body.cost);
		this.overallCost += body.cost;
	}

	public void visit(Car car) {
		System.out.println(car.cost);
		this.overallCost += car.cost;
	}

}
