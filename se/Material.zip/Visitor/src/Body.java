class Body implements ICarElement {
    double cost = 5005.0;
	public void accept(ICarElementVisitor visitor) {
        visitor.visit(this);
    }
}