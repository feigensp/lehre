class Car implements ICarElement {
    ICarElement[] elements;
    double cost = 10000;
    public Car() {
        //create new Array of elements
        this.elements = new ICarElement[] { new Engine(), new Wheel("front left"),
            new Wheel("front right"), new Wheel("back left") ,
            new Wheel("back right"), new Body() };
    }
 
    public void accept(ICarElementVisitor visitor) {    
    	visitor.visit(this);
    	
    	for(ICarElement elem : elements) {
            elem.accept(visitor);
        }    
    	if (visitor instanceof CostVisitor) {
    		CostVisitor c_v = (CostVisitor)visitor;
    		System.out.println(c_v.overallCost);
    	}
    }
}