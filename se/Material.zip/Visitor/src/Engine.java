class Engine implements ICarElement {
    double cost = 2500;
	public void accept(ICarElementVisitor visitor) {
        visitor.visit(this);
    }
}