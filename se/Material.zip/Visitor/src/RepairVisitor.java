
public class RepairVisitor implements ICarElementVisitor{

	public void visit(Wheel wheel) {
		if(wheel.zustandInMM < 4) {
			System.out.println("Switching wheel for repair.");
			wheel.zustandInMM = 7;
			wheel.cost += 300;
		}
	}

	public void visit(Engine engine) {
		// TODO Auto-generated method stub
		
	}

	public void visit(Body body) {
		// TODO Auto-generated method stub
		
	}

	public void visit(Car car) {
		// TODO Auto-generated method stub
		
	}

}
