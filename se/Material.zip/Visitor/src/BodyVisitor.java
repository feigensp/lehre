
public class BodyVisitor implements ICarElementVisitor{

	public void visit(Wheel wheel) {
		// TODO Auto-generated method stub
		
	}

	public void visit(Engine engine) {
		// TODO Auto-generated method stub
		
	}

	public void visit(Body body) {
		body.cost += 5000;
	}

	public void visit(Car car) {
		// TODO Auto-generated method stub
		
	}

}
