
public class TestClass {

	public static int fac(int n) {
		if( n <= 1) return 1;
		return fac (n-1) * n;
	}
	public static void main(String[] args) {
		List l = new List();
		//l.addAt(3, "Hallo");
		//l.addFirst("Welt");
		//l.addLast("!!!");
		l.addAt(3, new Car(50000));
		l.addFirst(new House(300000));
		l.addLast(new Car(12000));
		l.display();
		
		for(IComputeTaxes s: l) {
			System.out.println("old: " + s.computeTax());
			s.setTax(s.getTax() * 2);
			System.out.println("new: " +s.computeTax());
		}
		
		
		/*System.out.println(fac(10));
		
		// TODO Auto-generated method stub
		int i = 1;
		i = ~ 5 + 1;
		System.out.println(i);
		byte a = 28;
		byte b = 100;
		byte c = (byte) (a + b);
		System.out.println(c);
		int d = a + b;
		System.out.println(d);
		int e = -64;
		e >>>= 1;
		System.out.println(e);
		byte f = 010; 
		System.out.println(f);
		byte g = 15;
		g = (byte) (f|g);
		System.out.println(g);
		int num1 = 2; 
		int num2 = ++num1 * 3;
		System.out.println(num2);
		System.out.println(num1);
		num1 = 2;
		num2 = num1++ * 3;
		System.out.println(num2);
		System.out.println(num1);
		
		int x = 3;
		int k = 2;
//		if((k++ > 2) || (x < 5))

		//a == 2*/

	}	
	

}
