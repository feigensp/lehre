
public class Car implements IComputeTaxes {
	int price = 20000;
	public Car(int price) {
		this.price = price;
	}
	
	int myTax = 10;
	@Override
	public void setTax(int tax) {
		myTax = tax;

	}

	@Override
	public int computeTax() {
		// TODO Auto-generated method stub
		return myTax * price / 100;
	}

	@Override
	public int getTax() {
		// TODO Auto-generated method stub
		return myTax;
	}

}
