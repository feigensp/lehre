import java.security.InvalidParameterException;
import java.util.Scanner;

public class Calc {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean quit = false;
		while (!quit) {
			System.out.println("Bitte geben Sie die erste Zahl ein:");
			int zahl1 = sc.nextInt();
			System.out.println("Bitte geben Sie die zweite Zahl ein:");
			int zahl2 = sc.nextInt();
			System.out.println("Bitte geben Sie die auszuf�hrende Operation ein [+,-,/,*]:");
			String op = sc.next();
			compute(zahl1, zahl2, op);
			System.out.println("Wollen Sie beenden?");
			String ergebnis = sc.next();
			if (ergebnis.equals("ja") || ergebnis.equals("Ja"))
				quit = true;
		}

	}

	public static double compute(int zahl1, int zahl2, String op) {
		switch (op) {
			case "*":
				System.out.println(zahl1*zahl2);
				return zahl1*zahl2;
			case "+":
				System.out.println(zahl1+zahl2);
				return zahl1+zahl2;
			case "-":
				System.out.println(zahl1-zahl2);
				return zahl1-zahl2;
			case "/":
				System.out.println(zahl1/zahl2);
				return zahl1/zahl2;
		}
		throw new InvalidParameterException("unsuported exception");
	}

}
