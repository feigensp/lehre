
interface IDrivable {
	String printMax();
}
