
public class Test {

	static void test(ColorPoint c, Point p) {}
	static void test(Point p, ColorPoint c) {}
	
	public static void main(String[] args) {
		//ColorPoint cp = new ColorPoint();
		//test(cp,cp);
	}

}
