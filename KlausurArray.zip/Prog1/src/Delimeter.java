import java.util.Scanner;

public class Delimeter {
	public static void main(String[] args) {
		String orig = "// Printing the tokenized Strings\n	    while(scan.hasNext()){\n	        System.out.println(scan.next());\n	    }\n";
	    // Initialize Scanner object
	    Scanner scan = new Scanner(orig);
	    // initialize the string delimiter
	    scan.useDelimiter("\\W");
	    // Printing the tokenized Strings
	    StringBuilder sb = new StringBuilder();
	    while(scan.hasNext()){
	    	String temp = scan.next();
	    	if (temp.equals("out"))
	    		temp = "AAA";
	        sb.append(temp);
	    }
	    // closing the scanner stream
	    scan.close();
	    
	    System.out.println(sb.toString());
	    System.out.println(orig.replaceAll("\\bout\\b", "AAA"));
	}
}
