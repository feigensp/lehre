import java.util.Scanner;

public class Adventure {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		String command = "";
		System.out.println("Willkommen im Labyrinth der Programmierer. Finde des Ausgang und du wirst Weisheit erlangen!");
		while((command = sc.nextLine()) != null) {
			if (command.equals("q") || command.equals("quit")) {
				System.out.println("Farewell");
				System.exit(0);
			}
			else if (command.equals("n")) {
				System.out.println("Du gehst nach Norden.");
			}
			else if (command.equals("s")) {
				System.out.println("Du gehst nach S�den.");
			}
			else if (command.equals("o")) {
				System.out.println("Du gehst nach Osten.");
			}
			else if (command.equals("w")) {
				System.out.println("Du gehst nach Westen.");
			}
			else {
				System.out.println("Das habe ich nicht verstanden. Bitte versuche es nochmal.");
			}
		}
	}

}
