
public class ColorPoint extends Point {
	int color;
}
