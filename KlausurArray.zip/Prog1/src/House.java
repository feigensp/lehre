
public class House implements IComputeTaxes {

	int price = 200000;
	public House(int price) {
		this.price = price;
	}
	
	int myTax = 5;
	@Override
	public void setTax(int tax) {
		myTax = tax;

	}

	@Override
	public int computeTax() {
		// TODO Auto-generated method stub
		return myTax * price / 100;
	}

	@Override
	public int getTax() {
		// TODO Auto-generated method stub
		return myTax;
	}

}
