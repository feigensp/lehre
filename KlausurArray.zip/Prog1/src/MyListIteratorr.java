import java.util.Iterator;

public class MyListIteratorr implements Iterator<IComputeTaxes> {
	Node current = null;
	public MyListIteratorr(Node head) {
		current = head;
	}
	
	@Override
	public boolean hasNext() {
		return current != null;
	}

	@Override
	public IComputeTaxes next() {
		IComputeTaxes s = current.data;
		current = current.next;
		return s;
	}

}
