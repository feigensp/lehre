
public class Node {
	IComputeTaxes data;
	Node next;
	
	public Node(IComputeTaxes data) {
		this.data = data;
	}
}
