import java.util.Scanner;

public class NewTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//int zahl1 = sc.nextInt();
		//int zahl2 = sc.nextInt();
		//int ergebnis = zahl1 + zahl2;
		//System.out.println(ergebnis);
		//rechne(zahl1, zahl2);
		
		//int i = 1; 
		//i = ~i+1;
		//System.out.println(i);
	//	z�hleWochen(10);
		int e = -128;
		e >>= 1;
		System.out.println(e);
		byte f = 010;
		System.out.println(f);
		int num1 = 2; 
		int num2 = num1++ * 3;
		System.out.println(num2);
	}
	
	public static void rechne(int z1, int z2) {
		System.out.println(z1 + z2);
	}
	
	public static void z�hleWochen(int tage) {
		if (tage % 7 > 10)
			System.out.println("gr��er");
		System.out.println(tage % 7);
	}

}
