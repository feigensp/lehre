import java.util.Iterator;

public class List implements Iterable<IComputeTaxes>{
	Node head = null;;
	int size = 0;
	
	public void addFirst(IComputeTaxes s) {
		Node n = new Node(s);
		n.next = head;
		head = n;
		size++;
	}
	
	public void addAt(int position, IComputeTaxes s) {
		if(position == 0 || head == null) {
			addFirst(s);
			return;
		}
			
		if(position >= size) {
			addLast(s);
			return;
		}
		
		Node iterator = head.next;
		for(int i = 1; i < position && iterator != null; i++)
			iterator = iterator.next;
		Node n = new Node(s);
		n.next = iterator.next;
		iterator.next = n;
		size++;
	}

	public void addLast(IComputeTaxes s) {
		Node temp = head;
		while(temp.next != null)
			temp = temp.next;
		Node n = new Node(s);
		temp.next = n;
		size++;
	}
	
	public void display() {
		Node temp = head;
		while(temp!= null) {
			System.out.print(temp.data + " -> ");
			temp = temp.next;
		}
		System.out.println("Null");
	}

	

	@Override
	public Iterator<IComputeTaxes> iterator() {
		return new MyListIteratorr(head);
	}
}
