
public class Point {
	int x, y;
}
