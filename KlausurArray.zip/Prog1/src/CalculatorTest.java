import static org.junit.Assert.*;

import java.security.InvalidParameterException;

import static org.hamcrest.CoreMatchers.is;
import org.junit.Test;

public class CalculatorTest {

	@Test
	public void test() {
		int zahl1 = 0;
		int zahl2 = 0;
		String op = "*";
		
//		assertEquals(zahl1*zahl2, Calc.compute(zahl1, zahl2, op));
		assertThat(Calc.compute(zahl1, zahl2, op), is((double)zahl1*zahl2));
		
	}
	
	@Test(expected = InvalidParameterException.class)
	public void testException() {
		int zahl1 = 5;
		int zahl2 = 0;
		String op = "..";
		Calc.compute(zahl1, zahl2, op);
	}

}
