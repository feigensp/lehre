
public interface IComputeTaxes {
	public void setTax(int tax);
	public int computeTax();
	public int getTax();
}
