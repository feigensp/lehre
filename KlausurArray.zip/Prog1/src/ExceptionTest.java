
public class ExceptionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			System.out.println("result in for caller " + compute(6,2));
	}
	
	public static int compute(int a, int b) throws IllegalArgumentException {
		int result = 0;
		try {
			result = a / b;
			return result;
		}
		catch (IllegalArgumentException exception) 
		{
			System.out.println(exception.getMessage());
		}
		finally {
			
			result = -100;
			System.out.println("result in finally " + result);
			//return result;
		}
		return result;
	}

}
