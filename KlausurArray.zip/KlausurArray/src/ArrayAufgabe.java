
public class ArrayAufgabe {
/* Eingabe: 2-dimensionales Array mit nicht-negativen int-Werten
 * Ausgabe: Ein int-Wert, der sich wie folgt berechnet: 
 * (1) Finde h�chsten Wert f�r jede Spalte und addiere diese auf; 
 * (2) Finde niedrigsten Wert f�r jede Zeile und addiere diese auf; 
 * (3) Ziehe die 2. Summe von der 1. Summe ab und gebe das Ergebnis zur�ck. 
 * 
 */

	public static void main (String []args) {
		int[][] eingabe = {{3,5,7},{10,5,5},{2,9,5}};
		//MaxSpalten: 10 + 9 + 7 = 26; MinZeile = 3 + 5 + 2 = 10; result = 16
		System.out.println(compute(eingabe));
		int [][]eingabe2 = {{5,1},{8,4,5}};
		System.out.println(compute(eingabe2));
		
		int [][]eingabe3 = {{3,1,1},{5,1,1},{1,1,1}};
		System.out.println(compute(eingabe3));
	}
	public static int compute(int [][]eingabe) {
		for (int i = 0; i < eingabe.length; i++)
		{ 
			if(eingabe.length != eingabe[i].length)
				return -1;
		}
		int result = 0;
		int sumMinZeile = 0;
		int sumMaxSpalte = 0;
		for (int zeile = 0; zeile < eingabe.length; zeile++) {
			int maxSpalte = 0;
			int minZeile =eingabe[zeile][0];
			for (int spalte = 0; spalte < eingabe[zeile].length; spalte++) {
				if (minZeile > eingabe[zeile][spalte])
					minZeile = eingabe[zeile][spalte];
				if (maxSpalte < eingabe[spalte][zeile])
					maxSpalte = eingabe[spalte][zeile];
			}
			sumMinZeile += minZeile;
			sumMaxSpalte += maxSpalte;
		}
		result = sumMaxSpalte - sumMinZeile;
		return result;
	}
}
