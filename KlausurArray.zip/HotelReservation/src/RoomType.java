
public enum RoomType {
	einzel (80), doppel (140), suite (200);
	int kosten;
	RoomType(int kosten) {
		this.kosten = kosten;
	}
}
