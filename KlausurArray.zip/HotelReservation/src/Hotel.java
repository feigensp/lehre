import java.util.ArrayList;

public class Hotel {

	ArrayList<RoomType> reservierungen = new ArrayList<>();
	
	public Hotel() {
		
	}
	public void addReservation(RoomType t) {
		this.reservierungen.add(t);
	}
	public boolean removeReservation(RoomType t) {
		for(int i = 0; i < reservierungen.size(); i++) {
			if(reservierungen.get(i) == t) {
				reservierungen.remove(i);
				return true;
			}
		}
		return false;
	}
	public int computeEarnings() {
		int result = 0;
		for(RoomType t: reservierungen){
			result += t.kosten;
		}
		return result;
	}
	
	public void printReservations() {
		int einz = 0;
		int dop = 0;
		int sui = 0;
		for(RoomType t: reservierungen){
			switch(t)
			{
				case einzel:
					einz++;
					break;
				case doppel:
					dop++;
					break;
				case suite:
					sui++;
					break;
			}
		}
		System.out.println("Reservierungen Einzel: " + einz + ", Doppel: " + dop+", Suite: "+ sui);
	}
}
