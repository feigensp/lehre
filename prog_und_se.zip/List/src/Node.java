
public class Node {
	String data;
	Node next;
	
	Node(String d) {
		this.data = d;
		this.next = null;
	}
	
	public String longestString(String longestSoFar) {
		if(longestSoFar.length() < this.data.length())
			longestSoFar = this.data;
		
		if(this.next == null) {
			return longestSoFar;
		}
		
		return this.next.longestString(longestSoFar);
	}
	
	public String toString() {
		return " [" + this.data + "] ";
	}
}
