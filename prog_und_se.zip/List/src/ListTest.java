
public class ListTest {

	public static int add(int x, int y) {
		System.out.println("1.");
		return x + y;
	}
	
	public static double add(double x, double y) {
		System.out.println("2.");
		return x + y;
	}
	
	public static void main(String[] args) {
		add(3,7);
		add(3.0, 7.0);
		add(3.0, 7);
		Stack t = new Stack();
		System.out.println(t);
		
		/*List myList = new List();
		//myList.printContent();
		myList.addAtEnd("Hallo");
		myList.addAtEnd("Welt");
		myList.addAtEnd("!!!!einself");

		myList.addAtEnd("blablupiblipuubu");
		//myList.printContent();
		System.out.println(myList.longestStringRecursive());*/
		
		
		String testString = "(..a-sd[[(abac)asd]])";
		boolean korrekt = true;
		Stack stack = new Stack();
		for(int i = 0; i < testString.length(); i++) {
			if(testString.charAt(i) == '(' || testString.charAt(i) == '[')
				{
				stack.push(""+ testString.charAt(i));
				continue;
				}
			
			if (testString.charAt(i) == ')') {
				String aufStack = stack.peek();
				stack.pop();
				if(!aufStack.equals("(")) {
					System.out.println("Keine korrekte Klammerung!");
					korrekt = false;
					break;
				}
			}
			if (testString.charAt(i) == ']') {
				String aufStack = stack.peek();
				stack.pop();
				if(!aufStack.equals("[")) {
					System.out.println("Keine korrekte Klammerung!");
					korrekt = false;
					break;
				}
			}	
		}
		if(korrekt)
			System.out.println("Korrekte Klammerung");	
	}
		/*stack.push("Hallo");
		stack.push("Welt");
		System.out.println(stack.peek());
		stack.pop();
		System.out.println(stack.peek());*/
	}


