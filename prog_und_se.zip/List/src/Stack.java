
public class Stack {
	List data;
	
	public Stack() {
		this.data = new List();
	}
	
	void push(String data) {
		this.data.addFront(data);
	}
	
	String peek() {
		return data.getFront();
	}
	
	void pop() {
		data.removeFront();
	}
}
