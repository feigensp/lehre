
public class List {
	Node front;
	
	public List() {
		front = null;
	}
	
	public String getFront() {
		if(this.front == null)
			return "";
		return this.front.data;
	}
	
	public void printContent() {

		for (Node it = front; it != null; it = it.next) {
			System.out.print(it.toString());
	    }
	}
	public String longestStringRecursive() {
		if (front == null)
			return "";
		return front.longestString("");
	}
	
	public String longestString() {
		if(front == null)
			return "";
		String longestString = front.data;
		for (Node it = front; it != null; it = it.next) {
			if(longestString.length() < it.data.length())
				longestString = it.data;
	    }
		return longestString;
	}

	public void addAtEnd(String data) {
		Node n = new Node(data);
		if(front == null) {
			front = n;
		} else {
			for (Node it = front; it != null; it = it.next) {
				if(it.next == null) {
					it.next = n;
					break;
			}
		}
	}
		
	
	}
	
	public void addFront(String data) {
		Node n = new Node(data);
		n.next = front;
		front = n;
	}
	
	public String removeFront() {
		if(front == null)
			return "";
		
		String dataFromFront = front.data;
		front = front.next;
		return dataFromFront;
	}
}
