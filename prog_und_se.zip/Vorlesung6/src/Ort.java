public class Ort {
  String name;
  boolean inAusland = false;
  public Ort(String name) {
    this.name = name;
  }
  public Ort() {
    this.name = "Passau";
  }

  public void umziehen(String neuerOrt, Person p) {
    if(name.equals(neuerOrt)) {
      System.out.println("Du bleibst in der Stadt.");
    }
    else {
      int index = ummelden(neuerOrt);
      if (!inAusland) {
        p.alteWohnorte[index] = this;
        this.name = neuerOrt;
      }
      else {
        p.alteWohnorte[index] = this;
        this.name = "N/A";   
      }
    }
  }
  public int ummelden(String ort) {
    if(ort.equals("Ausland")) {
      inAusland = true;
      return 2;
    }
    else {
       inAusland = false;
       return 1; 
}}}
