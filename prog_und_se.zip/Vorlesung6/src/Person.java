class Person {
  String vorname;
  String nachname;
  int alter;
  Ort wohnort;
  Ort[] alteWohnorte;
  Person (int alter) {
    this.vorname = "Max";
    this.nachname = "Mustermann";
    this.alter = alter;
    this.wohnort = new Ort("Passau");
    alteWohnorte = new Ort[2];
  }
  
  void ziehtUm(String neuerWohnort) {
   wohnort.umziehen(neuerWohnort, this);
  }
  
  public static void main(String[] args) {
    Person ich = new Person(22);
    ich.ziehtUm("Ausland");
  }
}
