
public class Klausur {

	public static void main(String[] args) {
		int[][] data = {{5,2,7,8},{3,3,5,4}};
		System.out.println(getNumber(data));
	}
	
	static int getNumber(int[][] data) {
		int sum = 0;
		int size = 0;
		//get longest row
		for(int i = 0; i < data.length; i++) {
			if(size < data[i].length)
				size = data[i].length;
		}
		//save largest number of each column in helper array
		int[] helper = new int[size];
		
		//now search for largest number in each column
		for(int i = 0; i < data.length;i++){
			for(int k = 0; k < data[i].length; k++) {
				if(helper[k] < data[i][k])
					helper[k] = data[i][k];
			}
		}
		
		//sum up all numbers in the helper array  
		for(int i = 0; i < helper.length; i++) {
			System.out.println(helper[i]);
			sum+= helper[i];
		}
		
		return sum;
	}

}
