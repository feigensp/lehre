
public class Buch {
	final String ISBN; //Konstante, daher gro� geschrieben
	String name;
	int sales;
	String verlag;
	Person author;
	
	//Konstruktur mit 2 Parametern: (string,string)
	Buch(String isbn, String verlag) {
		this.ISBN = isbn; //Unbedingt Konstante definieren
		this.verlag = verlag;
		this.author = new Person("Mustermann");//Objekt vom Typ Person wird im Konstruktor der Klasse Buch angelegt
	}
	
	//Konstruktor mit nur einem Parameter (string)
	Buch(String verlag){
		this.verlag = verlag;
		ISBN = "DE-4343"; //Unbedingt Konstante definieren
	}
}
