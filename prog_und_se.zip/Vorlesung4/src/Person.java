
public class Person {
	String vorname;
	String nachname;
	String userName;
	int alter = 0;
	
	//Einziger Konstruktor dieser Klasse: Alle Objekte starten mit gleichem Vor- und Usernamen
	Person(String nachname) {
		this.nachname = nachname;
		this.vorname = "Max";
		this.userName = "007";
	}
	
	void hatGeburtstag(){
		this.alter += 1;
	}
	
	boolean istVollj�hring() {
		//Wenn nur eine Anweisung nach if bzw. else-Statement folgt, kann "{,}" weggelassen werden
		if(this.alter >= 18) 
			return true;
		 else 
			return false;
	}
	
	//Switch-Case Anweisung: Trifft nur genau die Werte
	void gebeStrafkatalogMitSwitchAus() {
		switch(this.alter){
			//Da break bei case 14 fehlt, wird "Leichte Jugendstrafe" beim Alter von 14 als auch 15 ausgegeben
			case 14:
			case 15:
				System.out.println("Leichte Jungendstrafe");
				break;
			case 16:
				System.out.println("Jugendstrafe");
				break;
			case 18:
				System.out.println("Volles Strafrecht");
			break;
			default: 
				System.out.println("Wei� ich nicht.");
		}
	}
	
	//Geschachtelte If-Anweisungen: Genau, aber un�bersichtlich
	void gebeStrafkatalogMitIfAus() {
		if(this.alter < 14) {
			System.out.println("Nicht strafm�ndig");
		} else if(this.alter >= 14 && this.alter <= 15) {
			System.out.println("Leichte Jungendstrafe");
		} else if (this.alter >= 16 && this.alter <= 17) {
			System.out.println("Jungendstrafe");
		} else {
			System.out.println("Volles Strafrecht");
		}
	}
}
