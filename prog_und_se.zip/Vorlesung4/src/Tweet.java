
public class Tweet {
	short zeichenl�nge;
	final short MAX_ZEICHEN = 140;
	boolean bild;
	short bilderAnzahl;
	String text;
	Person author;
	
	void setAuthor(Person p){
		this.author = p;
	}
	
	//Klasse hat keinen eigenen Konstruktor definiert,
	//dadurch existiert der Standardkonstruktor: Tweet(){}
}
