
public class Buchsammlung {
	Buch buch1;
	Buch buch2;
	Buch buch3;
}
