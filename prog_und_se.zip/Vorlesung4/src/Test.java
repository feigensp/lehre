
public class Test {

	//�blicherweise wird eine eigene Testklasse angelegt,
	//bei der es eine Main-Methode gibt
	//Main-Methode dient als Startpunkt eines Programmes
	public static void main(String[] args) {
		// Ein Objekt vom Typ / der Klasse "Buch" wird angelegt / instantiiert und der Konstruktor (string,string) verwendet
		Buch meinBuch = new Buch("5-32443","IEEE");
		// Ein Objekt vom Typ / der Klasse "Person" wird angelegt / instantiiert
		Person p = new Person("Mustermann");
		//Aufruf der Funktion hatGeburtstag auf das Objekt p 
		p.hatGeburtstag();
		//Ausgabe des Alters vom Objekt p
		System.out.println(p.alter);
		//Aufruf einer Methode vom Objekt p
		System.out.println(p.istVollj�hring());
		p.alter = 16;
		
		//Verschiedene Methodenaufrufe auf dem Objekt p
		p.gebeStrafkatalogMitSwitchAus();
		p.hatGeburtstag();
		p.gebeStrafkatalogMitSwitchAus();
		p.hatGeburtstag();
		p.gebeStrafkatalogMitIfAus();
		
		//Fehler: Konstruktor Person(){} existiert nur, falls wir keinen anderen definiert haben
		//Person p2 = new Person();
		Tweet t = new Tweet(); //Okay, da wir keinen anderen Konstruktor definiert haben
	}

}
