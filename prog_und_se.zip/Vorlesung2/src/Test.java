
public class Test {

	//Startmethode eines jeden Java-Programmes
	public static void main(String[] args) {
		//Beispiel 1: Einer- und Zweierkomplement in Java
		int r = 5;
		r = ~r+1; //~ macht Einerkomplement, daher +1 draufrechnen, um die exakt gleiche, negative Zahl zu bekommen
		System.out.println(r); //Dieser Befehl sort f�r die Ausgabe auf der Konsole
		
		
		//Beispiel Anzahl Wochen berechnen mit Modulo
		int anzahlWochen1 = 0;
		int anzahlWochen2 = 0;
		
		//Eine Z�hlschleife von 1 bis 365
		for(int i = 1; i <= 365; i++){
			//Kurzform f�r If mit Zuweisung!
			anzahlWochen1 = i%7 == 0 ?  anzahlWochen1 + 1 : anzahlWochen1;
			
			if(i%7 == 0) {
				anzahlWochen2++;
				//Alternativ: anzahlWochen2 += 1; // :) 
			}
		}
		System.out.println(anzahlWochen1);
		
		//Weiteres Beispiel f�r Zuweisung basierend auf einer Bedingung
		int alter = 19;
		String msg = alter >= 18 ? "Eintritt erlaubt" : "Du bist zu jung!";
		System.out.println(msg);
		
		//Unterschied & mit &&
		//& wertet immer beide Ausdr�cke aus -> hier Absturz, da Division mit 0
		int k = 3;
		if(k!=0 && 10/k > 0){
			System.out.println(10/k);
		}
		else {
			System.out.println("Geht nicht!");
		}
		
	}
		

}
