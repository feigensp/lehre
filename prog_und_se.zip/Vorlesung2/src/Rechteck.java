
public class Rechteck {
	Linie l1;
	Linie l2;
	Linie l3;
	Linie l4;
}
