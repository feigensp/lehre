
public class Datentypen {
	boolean eingeschrieben = true;
	public static void main(String args[]){
		double zahl = 5;
		System.out.println(zahl);
	}
}
