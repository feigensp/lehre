
public class Auto {
	String marke;
	int bauJahr;
	boolean sitzheizung;
	short ps;
	final byte EURONORM = 6;
	float tankStand;
	boolean elektro;
	Fahrzeughalter halter;
	//Reifen vornLinks;
}
