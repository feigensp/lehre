
public class Person {
	String vorname;
	String nachname;
	String userName;
}
