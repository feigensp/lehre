
public class Fahrzeughalter {
	String name;
	String wohnort;
}
