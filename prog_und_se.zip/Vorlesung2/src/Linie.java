
public class Linie {
	Punkt start;
	Punkt ende;
}
