import java.util.ArrayList;

public class MyDataStructure<T> implements Iterable<T> {
	private ArrayList<T> hiddenList = new ArrayList<T>();
	
	@Override
	public Iterator<T> createIterator() {
		return new MyIterator<>(hiddenList);
	}
	
	public void add(T data) {
		this.hiddenList.add(data);
	}
	
	class MyIterator<T> implements Iterator<T> {
		private ArrayList<T> iteratorList;
		int index = -1;
		
		MyIterator(ArrayList<T> iteratorList) {
			this.iteratorList = iteratorList;
			index = iteratorList.size();
		}
		@Override
		public void remove() {
			if (index < 0 || index >= iteratorList.size())
				return;
			iteratorList.remove(index);
		}

		@Override
		public T next() {
			index--;
			if (index < 0 || index >= iteratorList.size())
				return null;
			return iteratorList.get(index);
		}

		@Override
		public boolean hasNext() {
			if (index >= 1)//iteratorList.size()-1)
				return true;
			return false;
		}
		
	}

}
