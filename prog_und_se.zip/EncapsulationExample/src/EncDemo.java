
public class EncDemo {

	public static void main(String[] args) {
		ListInterface<String> myList = new MyArrayList<>();
		myList.add("Hallo");
		myList.add("Welt");
		
		foo(myList);
		//System.out.println(myList.getData(0));
	}

	static void foo(ListInterface<String> myList) {
		System.out.println(myList.getData(0));
	}
}
