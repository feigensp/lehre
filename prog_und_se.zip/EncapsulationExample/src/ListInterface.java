
public interface ListInterface <T>{
	public void add(T data);
	public T getData(int pos);
}
