import java.util.ArrayList;

public class MySecureList <T> implements ListInterface<T>{
private ArrayList<T> list = new ArrayList<>();
	
	public void add(T data) {
		System.out.println("log: encrypting data");
		list.add(data);
	}
	
	public T getData(int pos) {
		if (pos >= this.list.size())
			return null;
		else 
		{
			System.out.println("decrypting data");
			return list.get(pos);
		}
			
	}
}
