import java.util.ArrayList;

public class MyArrayList <T> implements ListInterface<T> {
	private ArrayList<T> list = new ArrayList<>();
	
	public void add(T data) {
		System.out.println("log: add new data");
		list.add((T) "add entry");
		list.add(data);
	}
	
	public T getData(int pos) {
		if (pos >= this.list.size())
			return null;
		else 
			return list.get(pos);
	}
}
