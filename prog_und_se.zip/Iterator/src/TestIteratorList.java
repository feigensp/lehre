
public class TestIteratorList {
	public static void main(String[] args){
		MySuperList<String> list = new MySuperList<>();
		list.add("Hallo");
		list.add("Welt");
		
		Iterator<String> it = list.createIterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
