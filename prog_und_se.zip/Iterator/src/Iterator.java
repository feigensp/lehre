
public interface Iterator <T> {
	public void remove();
	public T next();
	public boolean hasNext();
}
