import java.util.ArrayList;

public class MySuperList<T> implements Iterable<T>{

	private ArrayList<T> hiddenList = new ArrayList<T>();
	
	@Override
	public Iterator<T> createIterator() {
		// TODO Auto-generated method stub
		return new MySuperListIterator<T>(hiddenList);
	}
	
	public void add(T data) {
		this.hiddenList.add(data);
	}
	
	class MySuperListIterator<T> implements Iterator<T> {
		private int index = -1;
		private ArrayList<T> superList;
		
		public MySuperListIterator(ArrayList<T> superList) {
			this.superList = superList;
		}
		
		@Override
		public void remove() {
			if (this.index < 0 || this.index >= superList.size())
				return;
			this.superList.remove(index);
		}

		@Override
		public T next() {
			this.index++;
			if(this.index >= superList.size())
				return null;
			return superList.get(this.index);
		}

		@Override
		public boolean hasNext() {
			if (this.index < superList.size()-1)
				return true;
			return false;
		}
		
	}

}
