
public class Test {

	public static void main(String[] args) {
		Dreieckszahl dz = new Dreieckszahl();
		//Array anlegen
		int[] data = {3,5,6};
		//Mittelwert berechnen und ausgeben
		System.out.println(dz.average(data));
		
		//Ausgaben der Dreieckszahl mittels verschiedener Schleifen
		System.out.println(dz.dreiecksZahl(4));
		System.out.println(dz.dreiecksZahl2(4));
		System.out.println(dz.dreiecksZahl3(4));
		dz.questionInLecture();
		
		//Verschachtelte Z�hlschleife
		double loop = 0.0;
		do{
			loop += 0.1;
			System.out.println(loop);
			while(loop != 1.0) {//Hier schlechte Abbruchbedingung
				loop += 0.1;
				if(loop > 1.1)
					break;
			}
		} while(loop > 0.9 & loop < 1.1);
		System.out.println(loop);
	}

}

