
public class Dreieckszahl {
	
	int average(int[] data) {
		int sum = 0;
		for(int i = 0; i < data.length;i++) {
			sum = sum + data[i];
		}
		return sum / data.length;
	}
	
	//While-Schleife: Pr�fung auf Bedingung vor der ersten Ausf�hrung
	public int dreiecksZahl(int n) {
		  int sum = 0;
		  int k = 0;
		  while(k <= n) {
		    sum += k;
		    ++k;
		  }
		  return sum;
		}
	
	//While-Schleife: Garantierte erste Ausf�hrung
	public int dreiecksZahl2(int n) {
		  int sum = 0;
		  int k = 0;
		  do {
		    sum = sum + k;
		    k = k + 1;
		  } while(k <= n);
		  return sum;
		}
	
	//Z�hlschleife
	public int dreiecksZahl3(int n) {
		  int sum = 0;
		  for (int k = 0; k <= n; ++k) {
		    sum = sum + k; //alternativ: sum += k;
		  }
		  return sum;
		}

	public void questionInLecture()
	{
	  int line = 1;
	  while (line <= 5) {
	    int star = 1;
	    while (star <= 2 * line) {
	      System.out.print("*");
	      ++star;
	    }
	    System.out.println();
	    ++line;
	  }
	}



}
