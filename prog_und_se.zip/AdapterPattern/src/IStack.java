
public interface IStack <T>{
	public void push(T d);
	public T peek();
}
