import java.util.ArrayList;

public class MyList<T> extends ArrayList<T>{
	
}
