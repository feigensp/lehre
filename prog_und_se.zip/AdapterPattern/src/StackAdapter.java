
public class StackAdapter<T> implements IStack<T> {

	MyList<T> hiddenDataStructure = new MyList<>();
	
	@Override
	public void push(T d) {
		hiddenDataStructure.add(0, d);
	}

	@Override
	public T peek() {
		return hiddenDataStructure.get(0);
	}

}
