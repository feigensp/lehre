
public class Klient {

	public static void main(String[] args) {
		IStack<String> myData = new StackAdapter<>();
		myData.push("Hallo");
		myData.push("WElt");
		System.out.println(myData.peek());

	}

}
