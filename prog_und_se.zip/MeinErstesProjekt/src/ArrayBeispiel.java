
public class ArrayBeispiel {

	public static void main(String[] args) {
		int[][] test = new int[3][3];
		
		for (int i = 0; i < test.length; i++) {
			for (int k = 0; k < test[i].length; k++)
				test[i][k] = 100;
		}
		
		for(int[] i: test) {
			for (int k: i) {
				System.out.println(k);
			}
		}

	}

}
