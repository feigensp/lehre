import java.util.Scanner;

public class Pizzeria {

	public static void main(String[] args) {
		ZutatenF�rPizza ersteZutat = null;
		ZutatenF�rPizza zweiteZutat = null;
		
		System.out.println("Welche Zutat soll es sein? (K f�r K�se und S f�r Salami)");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String s2 = sc.nextLine();
		
		if(s.equals("K")) {
			ersteZutat = ZutatenF�rPizza.K�se;
		} else if (s.equals("S")) {
			ersteZutat = ZutatenF�rPizza.Salami;
		}
		if(s2.equals("K")) {
			zweiteZutat = ZutatenF�rPizza.K�se;
		} else if (s2.equals("S")) {
			zweiteZutat = ZutatenF�rPizza.Salami;
		}
		
		double gewinn = ersteZutat.berechneGewinn() + zweiteZutat.berechneGewinn();
		System.out.println("Gewinn der Pizzeria: " + gewinn);
	}

}
