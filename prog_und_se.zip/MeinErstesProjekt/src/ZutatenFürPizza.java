
public enum ZutatenF�rPizza {
	K�se(0.1, 1.0, "K�se"), Salami(0.5, 1.5, "Salami");
	
	double einkaufsKosten;
	double verkaufsKosten;
	String zutat;
	
	private ZutatenF�rPizza(double e, double v, String s) {
		this.einkaufsKosten = e;
		this.verkaufsKosten = v;
		this.zutat = s;
	}
	
	public double berechneGewinn() {
		return this.verkaufsKosten - this.einkaufsKosten;
	}
}