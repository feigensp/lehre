
public class Punkt {
	int x;
	int y;
}
