import java.util.Date;

public class Tweet {
	String text;
	TwitterUser user;
	Date created;
	
	void setText(String text){
		this.text = text;
	}
	
	String tweet() {
		System.out.println(this.text);
		return this.text;
	}
}
