
public class MeineErsteKlasse {

	public static void main(String [] args){
		final int days_in_year = 365;
		int hours_in_day = 24;
		//System.out.println(days_in_year * hours_in_day);
		//boolean hasChildren = 0; //FALSCH!
		
		Tweet myNewTweet = new Tweet();
		
		//System.out.println(myNewTweet.tweet());
		myNewTweet.setText("Mein erster Tweet!");
		
		myNewTweet.tweet();// + myNewTweet.tweet());
		
		long a = 23242424242242l;
		byte b = 23;
		char meineVariable = 'a';
		
		switch (meineVariable) {
		case 'b':
			System.out.println("b ist in variable c");
			break;
		case 'a':
			System.out.println("a ist in variable c");
			break;
		}
		
		if (meineVariable == 'b') {
			System.out.println("b ist in variable c");
		} else if (meineVariable == 'a') {
			System.out.println("a ist in variable c");
		}
	}
}
