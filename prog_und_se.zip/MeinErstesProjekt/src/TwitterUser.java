import java.util.Date;

public class TwitterUser {
	String name;
	String vorname;
	String ID;
	String profileName;
	Date dateOfBirth;
	//Followers .... ???
}
