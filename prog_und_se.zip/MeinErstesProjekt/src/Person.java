
public class Person {
	String name;
	int alter;
	static int anzP = 0;
	
	Person(String name){
		this.name = name;
		this.alter = 0;
		anzP++;
	}
	
	static boolean vergleicheAlter(Person p1, Person p2) {
		if (p1.alter == p2.alter)
		{
			return true;
		}
		else 
		{
			return false;
		}
		
		//return p1.alter == p2.alter;
	}
	
	boolean vergleicheAlterInstanz(Person otherPerson) {
		return this.alter == otherPerson.alter;
	}
	
	void hatGeburtstag() {
		this.alter++;
	}
	
	void getOlder() {
		this.hatGeburtstag();
		hatGeburtstag();
	}
	
	int getAlter() {
		return this.alter;
	}
	
	static int getAnzahlPersonen() {
		return anzP;
	}
	
	public static void main(String[] args) {
		//System.out.println(getAnzahlPersonen());
		Person peter = new Person("Peter");
		//System.out.println(peter.getAlter());
		peter.hatGeburtstag();
		//System.out.println(peter.alter);
		Person hilda = new Person("Hilda");
		System.out.println(Person.vergleicheAlter(peter, hilda));

	}

}
