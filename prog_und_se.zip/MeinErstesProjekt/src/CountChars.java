
public class CountChars {

	public static void main(String[] args) {
		System.out.println(countChar("Hallo Welt!   ", ' '));
		
	}
	
	static int countChar(String suchString, char suchZeichen) {
		int counter = 0;
		for(int i = 0; i < suchString.length(); i++) {
			if(suchString.charAt(i) == suchZeichen) {
				counter++;
			}
		}
		return counter;
	}
	
	
	public static int countChar2(char c, String s) {
		int counter = 0;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == c)
				counter ++;
		}
		return counter;
	}

}
