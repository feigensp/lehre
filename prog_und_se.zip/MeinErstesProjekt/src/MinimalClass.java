import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Timer;

public class MinimalClass {

	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, SecurityException {
		
		MinimalClass MinimalClass = new MinimalClass();// .foo();
		MinimalClass.foo();
		//var myString = new String();
		
		long start = System.currentTimeMillis();
		String test = "";
		for(int i = 0; i < 10000; i++)
			test = test + i;
		long gesamt = System.currentTimeMillis() - start;
		System.out.println("Mit String: " + gesamt);
		
		start = System.currentTimeMillis();
		StringBuilder test2 = new StringBuilder("");
		for(int i = 0; i < 10000; i++)
			test2.append(i);
		gesamt = System.currentTimeMillis() - start;
		System.out.println("Mit StringBuilder: " + gesamt);
		
		
		/*MinimalClass testObject = new MinimalClass();
		System.out.println(testObject.toString());
		
		Class metaDaten = testObject.getClass();
		System.out.println(metaDaten.getName());
		Object [] args2 = (Object [])args;
		for(Method m: metaDaten.getMethods()) {
			//System.out.println(m.getName());
			if (m.getName().equals("foo")) 
				m.invoke(null, args2);
		}*/
	}
	public static void foo() {
		int numbers[] = { 6, 4, 17, 23, 42, 5 };
		int min = numbers[0];
		for (int i = 0; i < numbers.length; i++) {
			if (min > numbers[i])
				min = numbers[i];
		}
		System.out.println(min);

	}
	
	@Override
	public String toString() {
		return "meine minimale Klasse";
	}
}
