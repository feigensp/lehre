
public class TryFinallyTest {

	public static void main(String[] args) {
		
		System.out.println(foo(3));
	}
	
	public static int foo(int a) {
		try {
			a = a +3;
			if (a > 5) {
				return a;
			}
			int b = a / 0;
		} catch(Exception e) {
			//e.printStackTrace();
			System.out.println("Huch, Fehler aufgetreten!");
		}
		finally {
			a = 0;
			System.out.println("Im finally Block:" + a);
			return a;
		}
		//return a;
	}
}
