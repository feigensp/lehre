
public class Linie {
	int x1;
	int y1;
	int x2;
	int y2;
	
	Punkt p1;
	Punkt p2;
}
