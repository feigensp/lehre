public class MyFirstClass {
	
	public static void main(String[] args) {
		
		String s;
		
		
		Linie l = new Linie();
		Object clone = new Object();
		clone.clone()
		Object.clone();
		
		
		
		
		
		
		
		double d = 0.0;
		while (d<1.0) {
			d = d + 0.1;
			System.out.println(d);
			
		}
		System.out.println("fertig");
		
		
		int alter = 0;
		
		if (alter != 0 && 100 / alter > 10) {
			System.out.println("Du darfst die Aktion ausf�hren!");
		}
		else {
			System.out.println("Du bist zu alt.");
		}
		
		String ausgabe = alter != 0 ? "ungleich 0" : "gleich 0";
	}
}