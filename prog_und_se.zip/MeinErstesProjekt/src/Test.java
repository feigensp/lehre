
public class Test {

	Test() {
		
	}
	
	public static void main(String[] args) {
		int a = 7;
		int b = 2;
		float c = 7/2;
		System.out.println(c);

	}

}
