
public class Rechteck {
	//Variante1
	Punkt p1;
	Punkt p2;
	Punkt p3;
	Punkt p4;
	
	//Variante2
	Punkt min;
	Punkt max;
	
	//Variante3
	Linie l1;
	Linie l2;
	Linie l3;
	Linie l4;
	
	//Variante4
	Linie l5;
	Linie l6;
}
