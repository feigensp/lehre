
public class Node {
	IPayTax data;
	Node next;
	
	public Node(IPayTax s) {
		this.data = s;
	}
}
