
public class Test {

	public static void main(String[] args) {
		List l1 = new List();
		l1.addAt(3, new Car(30000));
		l1.addFront(new Haus(400000));
		
		//l1.print();
		
		for(IPayTax s: l1){
			System.out.println("old: " + s.computeTax());
			s.setTax(s.getTax() * 2);
			System.out.println("new: " + s.computeTax());
		}
	}

}
