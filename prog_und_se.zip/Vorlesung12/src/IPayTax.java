
public interface IPayTax {
	public void setTax(int tax);
	public int getTax();
	public int computeTax();
}
