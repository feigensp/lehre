
public class Haus implements IPayTax {

	int price = 100000;
	int tax = 10;
	
	public Haus(int price) { this.price = price;}
	@Override
	public void setTax(int tax) {
		this.tax = tax;
	}

	@Override
	public int getTax() {
		// TODO Auto-generated method stub
		return tax;
	}

	@Override
	public int computeTax() {
		// TODO Auto-generated method stub
		return tax * price / 100;
	}

}
