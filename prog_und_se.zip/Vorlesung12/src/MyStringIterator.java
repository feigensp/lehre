import java.util.Iterator;

public class MyStringIterator implements Iterator<IPayTax> {

	Node current = null;
	MyStringIterator(Node head) {
		this.current = head;
	}
	
	@Override
	public boolean hasNext() {
		return current != null;
	}

	@Override
	public IPayTax next() {
		IPayTax s = current.data;
		current = current.next;
		return s;
	}

}
