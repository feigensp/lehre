
public class Car implements IPayTax {
	int price = 10000;
	int tax = 5;
	
	public Car(int price) { this.price = price;}
	@Override
	public void setTax(int tax) {
		this.tax = tax;
	}

	@Override
	public int getTax() {
		// TODO Auto-generated method stub
		return tax;
	}

	@Override
	public int computeTax() {
		// TODO Auto-generated method stub
		return tax * price / 100;
	}

}
