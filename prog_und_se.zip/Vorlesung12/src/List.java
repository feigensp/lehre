import java.util.Iterator;

public class List implements Iterable<IPayTax>{
	Node head = null;
	int size = 0;
	
	public void addFront(IPayTax s) {
		Node n = new Node(s);
		n.next = head;
		head = n;
		size++;
	}
	
	public void addLast(IPayTax s) {
		Node temp = head;
		while(temp.next != null) {
			temp = temp.next;
		}
		Node n = new Node (s) ;
		temp.next = n;
		size++;
	}
	
	public void addAt(int position, IPayTax s) {
		if(position == 0 || head == null) {
			addFront(s);
			return;
		}
		
		if (position >= size) {
			addLast(s);
			return;
		}
		
		Node iterator = head;
		for(int i = 1; i <= position && iterator != null; i++) {
			iterator = iterator.next;
		}
		Node n = new Node(s);
		n.next = iterator.next;
		iterator.next = n;
		size++;
	}
	
	public void print() {
		Node temp = head;
		while(temp != null) {
			System.out.print(temp.data + " -> ");
			temp = temp.next;
		}
		System.out.println("null");
	}

	@Override
	public Iterator<IPayTax> iterator() {
		// TODO Auto-generated method stub
		return new MyStringIterator(head);
	}
}
