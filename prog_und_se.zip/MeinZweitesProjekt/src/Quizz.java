
public class Quizz {

	public static void main(String[] args) {
		System.out.println(args[0]);
		System.out.println(args[1]);
		
		
		float a = 7;
		float b = 2.0f;
		double c = a / 2.0;
		System.out.println("c: " + c);

		int t = -1;
		int r = -1 * t++ + 3;

		System.out.println("t: " + t);
		System.out.println("r: " + r);
		
		int k = -1;
		int l = -1 * ++k + 3;

		System.out.println("k: " + k);
		System.out.println("l: " + l);

	}

}
