import java.util.ArrayList;

public class MyAdapter<T> implements DataStorage<T>{
	ArrayList<T> list = new ArrayList<T>();
	
	@Override
	public void put(T data) {
		list.add(data);
	}

	@Override
	public T get() {
		if (list.size() > 0)
			return list.remove(0);
		return null;
	}

}
