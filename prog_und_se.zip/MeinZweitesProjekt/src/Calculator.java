import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		boolean quit = false;
		while(quit == false) { //!quit
			System.out.println("Geben Sie die erste Zahl ein:");
			int zahl1 = sc.nextInt();
			System.out.println("Geben Sie die zweite Zahl ein:");
			int zahl2 = sc.nextInt();
			System.out.println("Geben Sie die Rechenoperation ein:");
			String operation = sc.next();
			
			calculate(zahl1, zahl2, operation);
			
			System.out.println("Wollen Sie beenden?");
			String answer = sc.next();
			if (answer.equals("ja") || answer.equals("Ja")) {
				quit = true;
			}
		}
		sc.close();
	}

	private static void calculate(int zahl1, int zahl2, String operation) {
		switch(operation) {
			case "+":
				System.out.println(zahl1 + zahl2);
				break;
			case "*":
				System.out.println(zahl1 * zahl2);
				break;
			case "/":
				System.out.println(zahl1 / zahl2);
				break;
			case "-":
				System.out.println(zahl1 - zahl2);
				break;
		}
	}

}
