
public interface DataStorage <T> {
	public void put(T data);
	public T get ();
}
