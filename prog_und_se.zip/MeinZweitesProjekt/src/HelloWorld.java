import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int z1 = sc.nextInt(); //Stunden jetzt
		int z2 = sc.nextInt(); //Stunden vergehen
		
		//System.out.println("In einem Karton passen 4 Flaschen.");
		//System.out.println("Wieviele Flaschen bleiben �brig?");
		if ((z1+z2) % 2 == 1){
			System.out.println("ungerade");
		}
		else {
			System.out.println("gerade");
		}
		
		//int summe = bildeSumme(z1,z2);
		//summe = bildeSumme(z1,summe, summe);
		//bildeSumme(z2,summe);
	}

	public static int bildeSumme(int zahl1, int zahl2) 
	{
		System.out.println("2 Zahlen");
		int summe = zahl1 + zahl2;
		System.out.println(summe);
		return summe;
	}
	public static int bildeSumme(int z1, int z2, int z3) 
	{
		System.out.println("3 Zahlen");
		int summe = z1 + z2 + z3;
		System.out.println(summe);
		return summe;
	}
}
