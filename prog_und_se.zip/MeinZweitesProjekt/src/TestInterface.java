
public class TestInterface {

	public static void main(String[] args) {
		DataStorage<String> ds = new MyAdapter<String>();
		ds.put("Hallo");
		ds.put("Welt");
		System.out.println(ds.get());
	}

}
