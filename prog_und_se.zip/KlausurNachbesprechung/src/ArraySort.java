import java.util.Arrays;

public class ArraySort {

	public static void main(String[] args) {
		int[] unsorted = {3,7,5,1};
		print(unsorted);
		sort(unsorted);
		print(unsorted);
	}

	private static void sort(int[] unsorted) {
		Arrays.sort(unsorted);
	}

	private static void print(int[] unsorted) {
		for(int i=0; i < unsorted.length; i++)
			System.out.print(unsorted[i]+" ");
		System.out.println();
	}

}
