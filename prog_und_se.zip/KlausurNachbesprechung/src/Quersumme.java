
public class Quersumme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int zahl = 111;
		System.out.println(quer4(zahl));
	}
	
	public static int quer(int zahl){
		if(zahl < 10)
			return zahl;
		int speicher = 0;
		for(int i = 10; i <= zahl; i=i*10){
			speicher = speicher + (zahl%i);
		}
		return speicher;
	}
	public static int quer2(int zahl){
		int modul = 10;
		int present = 0;
		int quer = 0;
		while(zahl > 0){
			present = zahl % modul;
			zahl = zahl - present;
			while(present >= 10) {
				present = present / 10;
			}
			quer = quer + present;
		}
		return quer;
	}
	
	public static int quer3(int zahl){
		int[] z = new int[zahl];
		int i = 0;
		for(int n=10;(zahl%n)!=zahl;n=n*10){
			z[i] = zahl%n;
			i++;
		}
		int sum = 0;
		for(int j = 0; i < z.length;j++)
			sum+=z[j];
		return sum;
		
	}
	
	public static int quer4(int zahl){
		int cross = 0;
		int i = 1;
		while(zahl% i != zahl){
			cross = cross + (zahl % (i*10)) / i;
			i = i*10;
		}
		return cross;
	}

}
