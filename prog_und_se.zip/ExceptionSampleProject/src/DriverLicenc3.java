
public class DriverLicenc3 {
	
	public static boolean getLicence(Person p) throws UnknownAgeException {
		if (p.alter < 0) {
			throw new UnknownAgeException();
		}
		
		if (p.alter >= 18)
		{
			System.out.println("Person kann F�hrerschein beantragen.");
			return true;
		}
		else {
			System.out.println("Person ist zu jung f�r den F�hrerschein.");
			return false;
		}
	}
}
