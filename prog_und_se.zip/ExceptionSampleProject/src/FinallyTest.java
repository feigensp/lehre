import java.lang.reflect.InvocationTargetException;

public class FinallyTest extends Object{

	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, SecurityException {
		
		//System.out.println("result in main: " + foo());
		FinallyTest t = new FinallyTest();
		Class c = t.getClass();
		System.out.println(c.getMethods()[2].invoke(null, args));
	}

	public static int compute(int a, int b) throws IllegalArgumentException{
		if (b==0)
			throw new IllegalArgumentException();
		return a / b;
	}
	
	public static int foo() {
		int result = 0;
		try {
			result = compute(6,0);
			System.out.println("result in try " + result);
			return result;
		}
		catch(IllegalArgumentException ex) {
			System.out.println(ex);
		}
		finally {
			result = 20;
			System.out.println("Result in finally " + result);
			//return result;
		}
		return result;
	}
}
