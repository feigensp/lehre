
public class Test {

	public static void main(String[] args) {
		Person p = new Person();
		p.name ="Peter";
		//p.alter = 20;
		
		try {
			DriverLicenc3.getLicence(p);
		}
		catch (UnknownAgeException ex) {
			ex.printStackTrace();
			System.out.println("Kann nicht entscheiden, da Alter nicht gesetzt: " + p.alter);
			p.alter = 20;
		}
		try {
			DriverLicenc3.getLicence(p);
		} catch(Exception e) {}
		
	}

}
