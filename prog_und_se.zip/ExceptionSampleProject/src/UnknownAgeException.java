
public class UnknownAgeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UnknownAgeException() {
		super();
	}
	
	public UnknownAgeException(String message) {
		super(message);
		if (message == null || message.length() <= 0) {
			message = "Age is negative -> no data available";
		}
		System.out.println(message);
	}
}
