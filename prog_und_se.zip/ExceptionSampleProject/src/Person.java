
public class Person {
	int alter = -1;
	String name;
}
