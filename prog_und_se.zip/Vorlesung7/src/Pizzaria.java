
public class Pizzaria {

	public static void main(String[] args) {
		Pizzaria piz = new Pizzaria();
		double gesamtPreis = piz.bestellePizza(Sorte.Salami);
		gesamtPreis += Extras.K�se.getPreis(0.9);
		
		System.out.println(gesamtPreis);

	}
	
	public double bestellePizza(Sorte pizza){
		
		switch(pizza) {
			case Salami:
				System.out.println("Du bestellst eine Salami-Pizza.");
				return 9.50;
			case Schinken:
				return 10.50;
			default:
				return 11.20;
		}
	}

}
