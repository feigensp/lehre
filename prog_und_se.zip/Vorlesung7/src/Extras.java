
public enum Extras {
	K�se (1.50), Ketchup (0.90);
	
	double preis;
	
	Extras (double p) {
		this.preis = p;
	}
	
	public double getPreis(double rabatt) {
		return preis*rabatt;
	}
}
