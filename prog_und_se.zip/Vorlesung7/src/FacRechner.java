
public class FacRechner {

	public static void main(String[] args) {
		System.out.println(fac(20000));

	}

	public static long fac(long i) {
		if (i > 0) {
			return i * fac(i-1);
		}
		return 1;
		
	}
}
