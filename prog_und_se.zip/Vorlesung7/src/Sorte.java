
public enum Sorte {
	Salami, Schinken, K�se, Hawai;
}
