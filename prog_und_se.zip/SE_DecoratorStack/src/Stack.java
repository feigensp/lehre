import java.util.LinkedList;

public class Stack<T> implements IStack<T> {

	LinkedList<T> data = new LinkedList<T>();
	
	@Override
	public void push(T t) {
		System.out.println((String)t);
		data.addLast(t);
	}

	@Override
	public T pop() {
		return data.removeLast();
	}

	@Override
	public int size() {
		return data.size();
	}
	
}
