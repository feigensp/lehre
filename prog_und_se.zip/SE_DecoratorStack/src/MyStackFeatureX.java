
public class MyStackFeatureX <T> extends StackDecorator<T>{

	MyStackFeatureX(IStack<T> stack) {
		super(stack);
		}

	@Override
	public void push(T data) {
		System.out.println("Feature X is coming!");
		super.push(data);
	}
}
