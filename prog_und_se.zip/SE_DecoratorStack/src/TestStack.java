
public class TestStack {

	@SuppressWarnings("rawtypes")
	public static void main(String[] args) {

		IStack myStack = new LockedStack(new Stack<String>());
		
		myStack.push("Hallo");
		LockedStack temp = (LockedStack)myStack;
		temp.lock();
		
		myStack.push("Welt");
		temp.unlock();
		myStack.push("Welt 2. Versuch");
		
		IStack myStack2 = new EncStack(myStack);
		myStack2.pop();
		myStack2 = new MyStackFeatureX<>(myStack2);
		myStack2.push("Test");
	}

}
