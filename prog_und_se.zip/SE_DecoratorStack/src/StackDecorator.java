
public abstract class StackDecorator<T> implements IStack<T> {
	IStack<T> delegate;
	
	StackDecorator(IStack<T> stack) {
		this.delegate = stack;
	}
	
	public void push(T t) {
		delegate.push(t);
	}
	
	public T pop() {
		return delegate.pop();
	}
	
	public int size() {
		return delegate.size();
	}
}
