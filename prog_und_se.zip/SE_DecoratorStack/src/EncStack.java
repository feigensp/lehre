
public class EncStack<T> extends StackDecorator<T> {

	EncStack(IStack<T> stack) {
		super(stack);
	}
	
	public void push(T t) {
		System.out.println("Encrypting");
		super.push(encrypt(t));
	}
	
	public T pop() {
		System.out.println("Decrypting");
		return decrypt(super.pop());
	}
	
	public T decrypt(T t) {
		return t;
	}
	
	private T encrypt(T t) {
		//magic
		return t;
	}
}
