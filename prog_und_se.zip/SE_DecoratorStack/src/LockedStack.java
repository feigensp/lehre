import java.util.concurrent.locks.Lock;

public class LockedStack<T> extends StackDecorator<T> {

	boolean lock = false;
	
	LockedStack(IStack<T> stack) {
		super(stack);
	}

	public void lock() {
		lock = true;
	}
	
	public void unlock() {
		lock = false;
	}
	
	@Override
	public void push(T t) {
		if(lock) {
			System.out.println("Cannot insert due to lock.");
		} else
		{
			super.push(t);
		}
	}
}
