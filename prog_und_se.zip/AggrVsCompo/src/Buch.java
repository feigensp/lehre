import java.util.*;;

public class Buch {
	private List<Autor> autor;
	private List<Kapitel> kapitel;
	
	Buch(Autor a) {
		autor = new ArrayList<>();
		autor.add(a);
		kapitel = new ArrayList<>();
		
	}
}
