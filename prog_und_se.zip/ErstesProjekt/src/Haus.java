
public class Haus implements ITaxpayer{

	@Override
	public double computeTax(int workingDays, int salaryPerHour) {
		// TODO Auto-generated method stub
		return workingDays / 10;
	}

}
