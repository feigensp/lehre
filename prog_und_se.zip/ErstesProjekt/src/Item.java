
public class Item {
	String name;
	int value;
	boolean found;
	
	Item(String n, int v) {
		name = n;
		value = v;
		found = false;
	}
}
