import java.util.Scanner;

public class Adventure {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Du willst einen Schatz suchen, bitte entscheide dich f�r eine Himmelsrichtung!");
		System.out.println("n = Norden, s = S�den, usw., q=Quit");
		
		int anzSchritteNord = 0;
		int anzSchritteOsten = 0;
		
		Gold[] sch�tze = new Gold[10];
		for (int i = 0; i <= sch�tze.length -1; i++) {
			sch�tze[i] = new Gold(i-1, i-2, 100 * i, 10*i);
			System.out.println(sch�tze[i].toString());
		}
		
		
		Gold schatz1 = new Gold(2, 2, 1000, 250);
		Gold schatz2 = new Gold(0, 1, 150, 1000);
		Gold schatz3 = new Gold(5, 1, 150, 1000);
		Gold schatz4 = new Gold(3, 3, 150, 1000);
		Gold schatz5 = new Gold(0, 5, 150, 1000);
		Gold schatz6 = new Gold(11, -1, 150, 1000);
		Gold schatz7 = new Gold(-3, -1, 150, 1000);
		
		Item hacke = new Item("Hacke", 5);
		Item sword = new Item("Schwert", 10);
		System.out.println(hacke);
		System.out.println(schatz7);
		
		String eingabe = "";
		while ((eingabe = sc.nextLine()) != null) {
			switch (eingabe) {
				case "n":
					System.out.println("Du gehst nach Norden.");
					anzSchritteNord++;
					break;
				case "s":
					System.out.println("Du gehst nach S�den.");
					anzSchritteNord--;
					break;
				case "o":
					System.out.println("Du gehst nach Osten.");
					anzSchritteOsten++;
					break;
				case "w":
					System.out.println("Du gehst nach Westen.");
					anzSchritteOsten--;
					break;
				case "q":
					System.out.println("Farewell");
					System.exit(0);
			}
			
			
			for(int i = 0; i < sch�tze.length; i++) {
				if (sch�tze[i].gefunden(anzSchritteNord, anzSchritteOsten)) {
					System.out.println("Du hast " + sch�tze[i].menge + " Gold im Alter von " + sch�tze[i].alter + " Jahren gefunden!");
				}	
			}
			
			
			
			
			if (schatz1.gefunden(anzSchritteNord, anzSchritteOsten)) {
				System.out.println("Du hast " + schatz1.menge + " Gold im Alter von " + schatz1.alter + " Jahren gefunden!");
			}
			if (schatz2.gefunden(anzSchritteNord, anzSchritteOsten)) {
				System.out.println("Du hast " + schatz2.menge + " Gold im Alter von " + schatz2.alter + " Jahren gefunden!");
			}
			
			if (anzSchritteNord == 3 && anzSchritteOsten == 2) {
				System.out.println("Yippehh! Du hast den Schatz gefunden!!!!111");
				System.exit(0);
			} else {
				if (anzSchritteNord < 3) {
					System.out.println("Du solltest evtl. nach Norden gehen.");
				}
				if (anzSchritteNord > 3) {
					System.out.println("Zu weit nach Norden!");
				}
				if (anzSchritteOsten < 2) {
					System.out.println("Im Osten riecht es nach Gold!");
				}
				if (anzSchritteOsten > 2) {
					System.out.println("Nee, doch nicht. War doch im Westen das Gold.");
				}
			}
		}
		System.out.println("Die Eingabe war: " + eingabe);
	}

}
