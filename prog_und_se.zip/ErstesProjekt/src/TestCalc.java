import static org.junit.Assert.*;

import org.junit.Test;
import static org.hamcrest.CoreMatchers.*;

public class TestCalc {

	@Test
	public void test() {
		int zahl1 = 3;
		int zahl2 = 3;
		String op = "-";
		
		assertThat(Rechner.calc(zahl1, zahl2, op), is((double)zahl1-zahl2));
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void testExceptionThrowing(){
		int zahl1 = 3;
		int zahl2 = 3;
		String op = "-4234";
		Rechner.calc(zahl1, zahl2, op);
	}
	

}
