
public class Rechner {

	public static void main(String[] args) {
		int i = 3;
		System.out.println(new Integer(i));
		//System.out.println(calc(3,5,"*"));
	}

	static double calc (int zahl1, int zahl2, String op) {
		switch(op) {
			case "*":
				return zahl1 * zahl2;
			case "+":
				return zahl1 + zahl2;
			case "-":
				return zahl1 - zahl2;
			case "/":
				return zahl1 / zahl2;
		}
		throw new IllegalArgumentException();
	}
}





/*int tage = 33;
int wochen = tage / 7;
int restTage = tage % 7;
System.out.println("Wochen: " + wochen + " Rest: " + restTage);
*/