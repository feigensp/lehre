
public interface ITaxpayer {
	public double computeTax(int workingDays, int salaryPerHour);
}
