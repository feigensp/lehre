import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Person implements ITaxpayer, Comparable<Person> {
	String vorname = "Max";
	String nachname = "Mustermann";
	int alter = 0;
	static int anzahlPersonen;
	
	Person(String v, String n) {
		this.vorname = v;
		this.nachname = n;
		anzahlPersonen++;
	}
	
	Person(String vorname) {
		initialize();
		this.vorname = vorname;
		anzahlPersonen++;
	}
	
	Person(int alter) {
		initialize();
		this.alter = alter;
		anzahlPersonen++;
	}
	
	void initialize() {
		this.vorname = "Max";
		this.nachname = "Mustermann";
		this.alter = -1;
	}
	
	void printVisitenkarte() {
		System.out.println("Visitenkarte von " + vorname + " "+ nachname);
	}
	
	public static void main(String[] args) {
		Person p = new Person("Maxily");
		Person p2 = new Person("M2");
		p.printVisitenkarte();
		System.out.println(Person.anzahlPersonen);
		
		ArrayList<ITaxpayer> steuerliste = new ArrayList<ITaxpayer>();
		ITaxpayer haus = new Haus();
		steuerliste.add(haus);
		steuerliste.add(p);
		
		for(ITaxpayer tax: steuerliste) {
			System.out.println(tax.computeTax(150, 10));
		}
		
		List<Person> persons = new ArrayList<Person>();
		Person pp1 = new Person("AAA");
		pp1.alter = 50;
		Person pp2 = new Person("BBB");
		pp2.alter = 20;
		persons.add(pp1);
		persons.add(pp2);
		Collections.sort(persons);
		for(Person temp: persons) {
		  System.out.println(temp.vorname + ", " + temp.alter );
		}

	}

	@Override
	public double computeTax(int workingDays, int salaryPerHour) {
		return workingDays * salaryPerHour * 8 / 42;
	}

	@Override
	public int compareTo(Person o) {
		if(this.alter < o.alter)
			return -1;
		else if (this.alter > o.alter)
			return 1;
		return 0;
	}

}
