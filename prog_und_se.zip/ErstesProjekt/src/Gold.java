
public class Gold {
	int menge;
	int alter;
	int ostLage;
	int nordLage;
	boolean gefunden = false;
	
	Gold(int ostLage, int nordLage, int alter, int menge) {
		this.menge = menge;
		this.alter = alter;
		this.ostLage = ostLage;
		this.nordLage = nordLage;
	}
	
	boolean gefunden(int nord, int ost) {
		if (gefunden == false && nord == nordLage && ost == ostLage) {
			gefunden = true;
			return true;
		}
		return false;
	}
	
	public String toString() {
		String ausgabe = "Nord: " + nordLage + " Ost: " + ostLage + " Menge: " + menge;
		//System.out.println(ausgabe);
		return ausgabe;
	}
}
