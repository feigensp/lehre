
class KeineAhnung {

	static void schreibeWas(String inhalt) {
		System.out.println(inhalt);
	}
	
	static double average(int[] data) {
		double sum = 0;
		for(int i = 0; i < data.length; i++) {
			sum += data[i];
		}
		return sum / data.length;
	}
	
	public static void main(String[] args) {
		int[] test = {1, 3, 5};
		System.out.println(average(test));
		
		
		String h1 = "Hi";//new String("Hi");
		String h2 = new String("Hi");
		String h3 = h1;
		if(h1.equals(h2)) {
			System.out.println("Strings sind die selben.");
		} else {
			System.out.println("Strings sind nicht die selben.");
		}
	}

}
