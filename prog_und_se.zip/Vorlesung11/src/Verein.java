
public class Verein {
	protected int Mitglieder;
	protected String Name;
	
	Verein(int m, String s){
		Mitglieder = m;
		Name = s;
	}
	
	public void print() {
		System.out.println("Mitglieder: " + Mitglieder + " Name: " + Name);
	}
}
