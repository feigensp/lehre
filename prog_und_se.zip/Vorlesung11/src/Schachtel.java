
public class Schachtel<T> {
	private T inDerSchachtel;
	
	public T getZeug() 
	{
		return inDerSchachtel;
	}
	
	Schachtel(T rein) {
		inDerSchachtel = rein;
	}
	
	public void print() {
		System.out.println(inDerSchachtel);
	}
	
	public static void main(String[] args) {
		Schachtel<Integer> s1 = new Schachtel<Integer>(42);
		s1.print();
		Schachtel<String> s2 = new Schachtel<String>("Hallo");
		s2.print();
	}

}
