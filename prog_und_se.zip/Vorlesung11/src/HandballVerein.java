import java.util.ArrayList;

public class HandballVerein extends Verein {
	String Liga;
	
	HandballVerein(int m, String s, String l) {
		super(m, s);
		Liga = l;
	}
	
	public void spiele() {
		System.out.println("gewonnen");
	}
	
	@Override
	public void print() {
		System.out.print("Liga: " + Liga);
		super.print();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Verein> list = new ArrayList<Verein>();
		
		list.add(new Verein(10, "Weimar"));
		list.add(new HandballVerein(100, "Weimar", "1. Bundesliga "));
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i) instanceof HandballVerein)
			{
				list.get(i).print();
				HandballVerein temp = (HandballVerein)list.get(i);
				temp.spiele();// .spiele();
			}
		}
		
		
		/*
		Verein v = new Verein(10, "Weimar");//new HandballVerein(100, "Weimar", "1. Bundesliga ");
		if(v instanceof HandballVerein)
			v.print();
		else
			System.out.println("nein");*/
	}

}
